from selenium import webdriver
from user import username,password
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains # ActionChains用来模拟鼠标操作 比如单击、双击、点击鼠标右键、拖拽等等
import time
from selenium.webdriver.common.keys import Keys
from city import city

from selenium.webdriver.chrome.service import Service

# 实现无可视化界面
from selenium.webdriver.chrome.options import Options

# 导入数据请求模块儿
import requests
# 导入表格输出模块儿
# import prettytable as pt
# 导入json模块
import json


def buy(from_city,to_city,date,num):
    # selenium防检测
    chrome_options = Options()
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")

    print('开始抢购。。。')
    url = 'https://kyfw.12306.cn/otn/resources/login.html'
    # 打开浏览器
    driver = webdriver.Chrome(executable_path='E:\driver\chromedriver.exe',
                              chrome_options=chrome_options)
    # 访问网址
    driver.get(url)

    # 输入账号
    driver.find_element(By.ID, 'J-userName').send_keys(username)
    # 输入密码
    driver.find_element(By.ID, 'J-password').send_keys(password)
    # driver.find_element_by_css_selector('#J-password').sendkeys(password)
    # 点击登录
    driver.find_element(By.ID, 'J-login').click()

    time.sleep(1)
    # btn = driver.find_element(By.ID,'nc_1_n1z')
    # ActionChains(driver).drag_and_drop_by_offset(btn,300,0).perform()

    # 滑块儿验证
    while True:
        try:
            span = driver.find_element(By.ID, "nc_1_n1z")
            actions = ActionChains(driver)  # 行为链实例化
            # time.sleep(1)  # 等待1秒钟
            # 经测量，滑块需要滑过的距离为300像素
            actions.click_and_hold(span).move_by_offset(300, 0).perform()  # 滑动
            # 释放行为链
            actions.release()
            time.sleep(1)
            a = driver.find_element(By.ID, "nc_1_refresh1")  # 查找刷新按钮，如果没有说明登录成功，执行except跳出循环
            a.click()  # 如果刚刚滑动失败，则点击刷新，重新滑动
        except Exception as e:
            print(e)
            break
    time.sleep(1)
    # 点击弹窗确定
    # driver.find_element(By.XPATH, '//a[contains(text(),"确定")]').click()
    # 点击车票预定
    driver.find_element(By.ID, 'link_for_ticket').click()
    time.sleep(1)
    # 点击弹窗确认
    # driver.find_element(By.ID, 'qd_closeDefaultWarningWindowDialog_id').click()
    # 选择出发地并清空
    driver.find_element(By.ID, 'fromStationText').click()
    driver.find_element(By.ID, 'fromStationText').clear()
    # 输入出发地
    # driver.execute_script("arguments[0].value='%s'" % '武汉', driver.fi  nd_element(By.ID,'fromStationText'))
    driver.find_element(By.ID, 'fromStationText').send_keys(from_city)
    driver.find_element(By.ID, 'fromStationText').send_keys(Keys.ENTER)

    # 选择目的地并清空
    driver.find_element(By.ID, 'toStationText').click()
    driver.find_element(By.ID, 'toStationText').clear()
    # 输入目的地  toStationText
    # driver.execute_script("arguments[0].value='%s'" % '北京', driver.find_element(By.ID,'toStationText'))
    driver.find_element(By.ID, 'toStationText').send_keys(to_city)
    driver.find_element(By.ID, 'toStationText').send_keys(Keys.ENTER)

    # 选择出发时间
    driver.find_element(By.ID, 'train_date').clear()
    driver.find_element(By.ID, 'train_date').send_keys(date)
    # 点击查询
    driver.find_element(By.ID, 'query_ticket').click()
    # 定位到所有的车票行
    # trs = driver.find_element(By.XPATH,'//tbody[@id="queryLeftTable"]/tr')
    # # # 检测是否能够预约
    # # for tr in trs:
    # #     tr_id = tr.get('id')
    # #     tds = driver.find_element(By.XPATH,f'//tr[@id={tr_id}]/td'.format()
    time.sleep(1)
    # 点击预约
    if num == 1:
        driver.find_element(By.XPATH, '//tbody[@id="queryLeftTable"]/tr[1]/td[13]/a').click()
    else:
        driver.find_element(By.XPATH, f'//tbody[@id="queryLeftTable"]/tr[{int(num)+1}]/td[13]/a').click()
    time.sleep(1)
    # 选择乘车人
    driver.find_element(By.XPATH, '//ul[@id="normal_passenger_id"]/li[1]/input').click()
    # 提交订单
    driver.find_element(By.ID, 'submitOrder_id').click()
    time.sleep(1)
    # 选择座位
    driver.find_element(By.XPATH, '//div[@id="erdeng1"]/ul[2]/li[2]/a').click()
    time.sleep(90)
    # 点击确认
    # driver.find_element(By.ID, 'qr_submit_id').click()
    # driver.find_element(By.ID, 'qr_submit_id').click()

from_city = input('请输入出发城市:')
to_city = input('请输入到达城市:')
date = input('请输入出发日期(2022-10-21):')
num = input('请输入要购买车票的序号:')
buy(from_city=from_city,to_city=to_city,date=date,num=int(num))
#
# # 读取城市的value
# from_value = city[from_city]
# to_value = city[to_city]
#
# # 获取车次列表的请求
# carlist_url = f'https://kyfw.12306.cn/otn/leftTicket/query?leftTicketDTO.train_date={date}&leftTicketDTO.from_station={from_value}&leftTicketDTO.to_station={to_value}&purpose_codes=ADULT'.format()
# print(carlist_url)
# # 伪装
# headers = {
#     'Cookie': 'JSESSIONID=6B830215CE85778D2399BC435C601591; tk=dM7trgPFyiRlMSHCCGs060V2WNey39nAwjWhDkYbeRwzih1h0; BIGipServerpassport=870842634.50215.0000; RAIL_EXPIRATION=1673311404529; RAIL_DEVICEID=eGbq97vxGmNRM9xJ4M43Qc9l9AbAxUJqwG-eXlTCRzkeNAiAX3ynh8sQ30dc1Q3S1KLlNVhf9KMuYY9VP6F0wpgVjUuezelC_HNqvAugPLE0DqH2Uf-pCihljh3cSt6A8TUHGZRSJPmk4ALqg_d7G1CvZL2BWVJi; guidesStatus=off; highContrastMode=defaltMode; cursorStatus=off; route=c5c62a339e7744272a54643b3be5bf64; fo=86ayr4qe4zqejyufsbQZqEyADx43x7Z60fT5bscmfqHzjFvuSIe8sW_5_5tzUF_SdlMlYlnP60QG3WI-fJxqa7SF18UhVcBSAR2-noE2SH-v2uuxZ5LTqGAcOrDRKZ2D9QiyEP2to9rNAf_e80WCygoT8JNLyuGFRC_mrJwWtJzyRxxiUY8oAOrxG9I; BIGipServerpool_passport=149160458.50215.0000; BIGipServerotn=787481098.38945.0000; uKey=686f85b974c9465c2e0a87668da4ac78fea764402eb897d1fa0f77d4f7ab81cb',
#     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
#
# }
# # 发起请求
# resp = requests.get(url=carlist_url, headers=headers)
# print(resp)
#
# # 将数据转为json数据
# json_data = resp.json()
#
# # 实例化表格对象
# tb = pt.PrettyTable()
# # 设置一个表头字段
# tb.field_names = [
#     '序号','车次','出发时间','到达时间','耗时','特等座','一等座','二等座','软卧','硬卧','硬座','无座'
# ]
# # 定义序号
# page = 0
# # 遍历所有数据
# for i in json_data['data']['result']:
#     # 用|来分割 返回列表 就可以根据列表索引位置来取值
#     index = i.split('|')
#     num = index[3] # 车次
#     start_time = index[8] # 出发时间
#     end_time = index[9] # 到达时间
#     use_time = index[10] # 耗时
#     topGrade = index[32] # 特等座
#     first_class = index[31] # 一等座
#     second_class = index[30] # 二等座
#     hard_sleeper = index[28] # 硬卧
#     hard_seat = index[29] # 硬座
#     no_seat = index[26] # 无座
#     soft_sleeper = index[23] # 软卧
#     # 保存到字典里
#     # dit = {
#     #     '车次':num,
#     #     '出发时间':start_time,
#     #     '到达时间':end_time,
#     #     '耗时':use_time,
#     #     '特等座':topGrade,
#     #     '一等座':first_class,
#     #     '二等座':second_class,
#     #     '软卧':soft_sleeper,
#     #     '硬卧':hard_sleeper,
#     #     '硬座':hard_seat,
#     #     '无座':no_seat
#     # }
#     tb.add_row([
#         page,
#         num,
#         start_time,
#         end_time,
#         use_time,
#         topGrade,
#         first_class,
#         second_class,
#         soft_sleeper,
#         hard_sleeper,
#         hard_seat,
#         no_seat
#     ])
#     page += 1
# print(tb)
#
#



