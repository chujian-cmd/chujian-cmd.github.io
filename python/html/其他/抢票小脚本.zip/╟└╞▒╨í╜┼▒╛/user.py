# 软帝云课堂
# 湛湛
# 开发时间：2022/10/22 17:00
username = '18972393828'
password = 'huangzhan888'